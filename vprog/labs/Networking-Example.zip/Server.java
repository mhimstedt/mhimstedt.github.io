import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class Server {

    private static int port = 12345;

    public static void main(String[] args) {

        try {
            ServerSocket serverSocket = new ServerSocket(port);

            /* Hier können wir annehmen, dass der Server gestartet wurde.
               Wenn das Öffnen des Sockets fehlschlug, springt Java
               direkt in den catch-Block.
             */
            System.out.println("Server gestartet. Warte auf Verbindung...");

            Socket socket = serverSocket.accept();

            ObjectOutputStream oos = new ObjectOutputStream(socket.getOutputStream());

            System.out.println("Client verbunden.");
            Person person = new Person("Max", "Mustermann");

            oos.writeObject(person);
            oos.flush();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}