import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.Socket;

public class Client {

    private static String host = "localhost";
    private static int port = 12345;

    public static void main(String[] args) {

        try (Socket socket = new Socket(host, port);
             ObjectInputStream ois =
                     new ObjectInputStream(socket.getInputStream())) {

            Person person = (Person) ois.readObject();

            System.out.println("Person empfangen:");
            System.out.println(person);

        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}